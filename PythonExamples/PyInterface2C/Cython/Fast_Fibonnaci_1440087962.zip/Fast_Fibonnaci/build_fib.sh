gcc -fpic -shared fib.c -o libfib.so
