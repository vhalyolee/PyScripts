"""
Inheritance vs. Composition
===========================

This exercise uses Flock classes from the multiple inheritance exercise.

In the exercise from the multiple inhertance lecture (particularly if you did
the bonus question) you may have noticed that as we broke up the classes to
isolate different behaviors into subclasses, we gained flexibility, but at
the expense of large numbers of classes.  You can pick and choose the rules
which govern movement, you have to create a new class to encapsulate those
choices.

In many cases this is fine, but it has the downside that it's not easy to
change the behaviors at run-time (for example, if you wanted a user to be
able to choose between different rules that they want to experiment with).
One way to overcome this limitation is to use "composition" rather than
inheritance to build the desired set of behaviors: the Flock has a
list of behaviors it follows, rather than inheriting it intrinsically.

This disitinction is sometimes referred to as "has a" relationships vs. "is a"
relations: a BoidsFlock "has a" Separation behavior rather than a BoidsFlock
"is a" SeparationFlock.

Question
--------

Add a new base class Behavior which has the following interface:

    class Behavior(object):

        def acceleration(self, flock):
            '''Return the contribution to acceleration from the behavior'''
            raise NotImplementedError

Modify the Flock classes in this module to create a new ComposedFlock class,
and a collection of Behavior subclasses for each of the "random",
"separation", "alignment", "cohesion" and "wall avoidance" behaviors.

If you run this code in canopy, a matplotlib animation will be created for the
simulation and you can watch the flocking behavior live.  To run the
animation outside of Canopy from the command prompt, use:

    ipython --gui=qt4 boids_solution.py

Bonus
-----

There are many other behaviors that you can implement:

* "seek" is a behavior which adds an acceleration component which moves the
  boids towards a specified target point:

    target_delta = position - target_position
    desired_velocity = normalize(target_delta) * max_speed
    acceleration = (desired_velocity - velocity) * weight

* "flee" is a behavior which adds an acceleration component which moves the
  boids away from a specified target point: the behavior is the same as "seek"
  but the desired velocity is the negative of the seek velocity.

* "pursuit" is similar to "seek," but the target is moving, so the target
  position is a projected future position for the target.

* "evasion" is similar to "flee" but with a moving target.  As with "pursuit"
  the target position is a projected future position for the target.

* "arrival" is similar to "seek", but the desired velocity is adjusted so that
  the boid slows down as it approaches the target point.

* "wander" is an alternative to random movement where the acceleration applied
  each step is remembered and adjusted slightly left or right, but constrained
  to lie on a circle ahead of the boid.

* "obstacle avoidance" is a behavior similar to wall avoidance that allows
  boids to fly around trees or other non-wall obstacles.  Objects ahead of the
  boid are projected perpendicular to the direction of motion and intersections
  of the projections with the location of the boid indicate potential future
  collisions.  The behavior generates an acceleration based on moving away
  from the center of the closest (ie. most dangerous) obstacle.

Many more possibilties are discussed at http://www.red3d.com/cwr/steer/gdc99/

As a concrete goal, you might add a food source that the boids "seek" and a
hawk to the forest which the boids want to "evade."  Initially you might just
move the hawk on a pre-determined path (such as a circle) that passes near the
food source, but you could also potentially give the hawk the "random",
"wander" or "pursuit" behaviors if you have written your behavior classes
well.

References
----------

Reynolds, C. W. (1987) Flocks, Herds, and Schools: A Distributed Behavioral
    Model, in Computer Graphics, 21(4) (SIGGRAPH '87 Conference Proceedings)
    pages 25-34.

Reynolds, C. W. (1999) Steering Behaviors For Autonomous Characters, in the
    proceedings of Game Developers Conference 1999 held in San Jose,
    California. Miller Freeman Game Group, San Francisco, California.
    Pages 763-782. (http://www.red3d.com/cwr/papers/1999/gdc99steer.html)

"""

from numpy import array, newaxis, zeros, zeros_like
from numpy.linalg import norm
from numpy.random import normal, uniform
from scipy.spatial import KDTree

class Flock(object):
    """ A base class for a similated flock of birds """

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = array(forest_size)
        self.n_dim = len(forest_size)

        self.positions = uniform(size=(self.size, self.n_dim))*self.forest_size
        self.velocities = zeros((size, self.n_dim))

    def accelerate(self):
        """ Accelerate the boids randomly """
        self.velocities += self._compute_acceleration()
        self._clip_velocity()

    def move(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self._clip_position()

    def do_one_step(self):
        """ Perform one step of the simulation """
        # a KDTree allows us to find nearest neighbors more quickly
        self._kd_tree = KDTree(self.positions)
        self.accelerate()
        self.move()

    def nearest_neighbors(self, count):
        """ Utility function to find n nearest neighbors.

        This uses SciPy's KDTree object, which is documented here:
        http://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.KDTree.html

        """
        # If you don't know anything about the kd-tree data structure, that's fine
        # for the purposes of the exercise: just treat this as a black box which
        # finds the n nearest boids to an array of positions, and also computes
        # the distances to the boids from each point in the array.

        distances, neighbors = self._kd_tree.query(self.positions, count+1,
                                                    self.eps)

        # first column is always the current boid, so ignore
        distances = distances[:, 1:]
        neighbors = neighbors[:, 1:]
        return distances, neighbors

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = zeros(shape=(self.size, self.n_dim))
        return accel

    def _clip_velocity(self):
        """ Ensure no boid is going faster than the max speed """
        speeds = norm(self.velocities, axis=-1)
        too_fast = speeds >= self.max_speed
        self.velocities[too_fast] = (self.velocities[too_fast] /
            speeds[too_fast, newaxis]) * self.max_speed

    def _clip_position(self):
        """ If beyond a wall, move back to wall location """
        for dimension in range(self.n_dim):
            collisions = self.positions[..., dimension] < 0
            self.positions[collisions, dimension] = 0
            collisions = self.positions[..., dimension] > self.forest_size[dimension]
            self.positions[collisions, dimension] = self.forest_size[dimension]


class Behavior(object):
    """ Abstract base class for behaviors """

    def __init__(self, weight=1.0, **kwargs):
        self.weight = weight

    def accelerate(self, flock):
        # subclasses must override this method to return the acceleration
        raise NotImplementedError()


class BehaviorFlock(Flock):
    """ A Flock subclass with a list of behaviors it follows """

    def __init__(self, size=100, forest_size=(150, 150)):
        super(BehaviorFlock, self).__init__(size, forest_size)
        self.behaviors = []

    def _compute_acceleration(self):
        accel = super(BehaviorFlock, self)._compute_acceleration()
        for behavior in self.behaviors:
            accel += behavior.acceleration(self)
        return accel


# rewrite all of the following classes as subclasses of Behavior

class RandomFlock(Flock):
    """A simulated flock of birds that moves randomly"""

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = normal(0, 1, (self.size, self.n_dim))
        return accel


class SeparatingFlock(Flock):
    """A flock where boids keep avoid their neighbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(SeparatingFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 10
        self.__weight = 1

    def separation(self):
        """Avoid nearby boids, repulsion is inversely proportional to distance"""
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        distances = distances.clip(0.1)
        neighbor_positions = self.positions[neighbors]
        deltas = neighbor_positions - self.positions[:, newaxis, :]
        accel = (deltas/distances[:, :, newaxis]**2).sum(axis=1)
        return accel

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(SeparatingFlock, self)._compute_acceleration()
        accel += self.separation() * self.__weight
        return accel


class AligningFlock(Flock):
    """A flock where boids move in the same direction as their neighbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(AligningFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 10
        self.__weight = 0.02

    def alignment(self):
        """ Tend towards average heading of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        avg_neighbor_velocities = self.velocities[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_velocities - self.velocities
        return avg_delta

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(AligningFlock, self)._compute_acceleration()
        accel += self.alignment() * self.__weight
        return accel


class CohesiveFlock(Flock):
    """A flock where boids move toward the centroid of their neigbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(CohesiveFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 51
        self.__weight = 0.02

    def cohesion(self):
        """ Tend towards average position of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        avg_neighbor_positions = self.positions[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_positions - self.positions
        return avg_delta

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(CohesiveFlock, self)._compute_acceleration()
        accel += self.cohesion() * self.__weight
        return accel


class WallAvoidingFlock(Flock):

    def wall_avoidance(self):
        """ If a wall is ahead, steer away from it """
        future_position = self.positions + self.velocities
        accel = zeros_like(self.velocities)
        for dimension in range(self.n_dim):
            # collision possible?
            collisions = ((future_position[..., dimension] < 0) | \
                          (future_position[..., dimension] >
                           self.forest_size[dimension]))
            # if so accelerate away from wall
            accel[collisions, dimension] = -self.velocities[collisions, dimension]
        return accel

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(WallAvoidingFlock, self)._compute_acceleration()
        accel += self.wall_avoidance()
        return accel


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation

    # create flock
    flock = BehaviorFlock()
    flock.behaviors = [Separation(), Alignment(), Cohesion(), WallAvoidance()]

    # create a matplotlib animation of the flock
    fig = plt.figure()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                         xlim=(0, 150), ylim=(0,150))

    flock_plot, = ax.plot([], [], 'bo', ms=6)

    def init():
        flock_plot.set_data([], [])
        return flock_plot,

    def animate(i):
        global flock_plot, flock

        flock.do_one_step()
        flock_plot.set_data(flock.positions[:, 0], flock.positions[:, 1])
        return flock_plot,

    ani = animation.FuncAnimation(fig, animate, frames=100,
                                  interval=1, blit=True, init_func=init)
    plt.show()
