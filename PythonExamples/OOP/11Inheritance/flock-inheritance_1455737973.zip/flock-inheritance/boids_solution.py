"""
Boids
=====

This exercise uses Flock classes from earlier examples.

Question
--------

In the constructor exercises you wrote a Flock class that moves randomly, and
another one that moves according to a set of simple rules ("separation",
"alignment" and "cohesion").  In this exercise you will take these two classes
(called RandomFlock and BoidFlock, respectively) and re-write (or "refactor")
them so that they both inherit from a common base class called Flock.

You should shift any methods that are shared between the two classes to the
Flock superclass as well.

If you run this code in canopy, a matplotlib animation will be created for the
simulation and you can watch the flocking behavior live.  To run the
animation outside of Canopy from the command prompt, use::

    ipython --gui=qt4 boids_solution.py

References
----------

Reynolds, C. W. (1987) Flocks, Herds, and Schools: A Distributed Behavioral
    Model, in Computer Graphics, 21(4) (SIGGRAPH '87 Conference Proceedings)
    pages 25-34.

"""

from numpy import array, newaxis, zeros, zeros_like
from numpy.linalg import norm
from numpy.random import normal, uniform
from scipy.spatial import KDTree

class Flock(object):
    """ A base class for a simulated flock of birds """

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = array(forest_size)
        self.n_dim = len(forest_size)

        self.positions = uniform(size=(self.size, self.n_dim))*self.forest_size
        self.velocities = zeros((size, self.n_dim))

    def accelerate(self):
        """ Accelerate the boids randomly """
        self.velocities += self._compute_acceleration()
        self._clip_velocity()

    def move(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self._clip_position()

    def do_one_step(self):
        """ Perform one step of the simulation """
        self.accelerate()
        self.move()

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = zeros(shape=(self.size, self.n_dim))
        return accel

    def _clip_velocity(self):
        pass

    def _clip_position(self):
        self.positions %= array(self.forest_size)


class RandomFlock(Flock):
    """A simulated flock of birds that moves randomly"""

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = normal(0, 1, (self.size, self.n_dim))
        return accel


class BoidFlock(Flock):
    """ A simulated flock of birds that moves according to simple rules """

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = array(forest_size)
        self.n_dim = len(forest_size)

        self.positions = uniform(size=(self.size, self.n_dim))*self.forest_size
        self.velocities = zeros((size, self.n_dim))

        # we don't expose these values in the constructor arguments: code which
        # wants to modify these can do so directly after the object is
        # initialized
        self.max_speed = 5.0
        self.eps = 0.0

        self.separation_neighbor_count = 10
        self.separation_weight = 1

        self.alignment_neighbor_count = 10
        self.alignment_weight = 0.02

        self.cohesion_neighbor_count = 51
        self.cohesion_weight = 0.02

    def separation(self):
        """ Avoid nearby boids, repulsion is inversely proportional to distance """
        distances, neighbors = self._nearest_neighbors(
            self.separation_neighbor_count)
        distances = distances.clip(0.1)
        neighbor_positions = self.positions[neighbors]
        deltas = neighbor_positions - self.positions[:, newaxis, :]
        accel = (deltas/distances[:, :, newaxis]**2).sum(axis=1)
        return accel

    def alignment(self):
        """ Tend towards average heading of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.alignment_neighbor_count)
        avg_neighbor_velocities = self.velocities[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_velocities - self.velocities
        return avg_delta

    def cohesion(self):
        """ Tend towards average position of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.cohesion_neighbor_count)
        avg_neighbor_positions = self.positions[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_positions - self.positions
        return avg_delta

    def do_one_step(self):
        """ Perform one step of the simulation """
        # a KDTree allows us to find nearest neighbors more quickly
        self._kd_tree = KDTree(self.positions)

        # update velocities and positions
        self.accelerate()
        self.move()

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = zeros_like(self.velocities)
        accel += self.separation() * self.separation_weight
        accel += self.alignment() * self.alignment_weight
        accel += self.cohesion() * self.cohesion_weight
        return accel

    def _clip_velocity(self):
        """ Ensure no boid is going faster than the max speed """
        speeds = norm(self.velocities, axis=-1)
        too_fast = speeds >= self.max_speed
        self.velocities[too_fast] = (self.velocities[too_fast] /
            speeds[too_fast, newaxis]) * self.max_speed

    def _nearest_neighbors(self, count):
        """ Utility function to find n nearest neighbors.

        This uses SciPy's KDTree object, which is documented here:
        http://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.KDTree.html

        """
        # If you don't know anything about the kd-tree data structure, that's fine
        # for the purposes of the exercise: just treat this as a black box which
        # finds the n nearest boids to an array of positions, and also computes
        # the distances to the boids from each point in the array.

        distances, neighbors = self._kd_tree.query(self.positions, count+1,
                                                   self.eps)

        # first column is always the current boid, so ignore
        distances = distances[:, 1:]
        neighbors = neighbors[:, 1:]
        return distances, neighbors


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation

    # create flock
    flock = BoidFlock()

    # create a matplotlib animation of the flock
    fig = plt.figure()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                        xlim=(0, 150), ylim=(0,150))

    flock_plot, = ax.plot([], [], 'bo', ms=6)

    def init():
        flock_plot.set_data([], [])
        return flock_plot,

    def animate(i):
        global flock_plot, flock

        flock.do_one_step()
        flock_plot.set_data(flock.positions[:, 0], flock.positions[:, 1])
        return flock_plot,

    ani = animation.FuncAnimation(fig, animate, frames=100,
                                  interval=1, blit=True, init_func=init)
    plt.show()
