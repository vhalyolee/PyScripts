
# A Flock of Boids
# ================
# 
# In the lectures we are developing classes and objects that model forests and fires.  In these exercises we are going to create classes and objects that model the creatures that might live in those forests.  In particular, we are going to write code inspired by [the classic "Boids" simulation](http://www.red3d.com/cwr/boids/) by Craig Reynolds.
# 
# We're going to write this in an object oriented style, so our first task is to create a class for our flock of birds flying through the forest.

# Create a class called `Flock` to represent the flock.


class Flock(object):
    """ A simulated flock of birds """


# Create a class called `Boid` to represent a single simulated bird.


class Boid(object):
    """ A simulated bird """


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
