"""
Boids
=====

This exercise pulls together much of what you've learned in the first half of
the course to build an OOP implementation of the
`Boids <http://www.red3d.com/cwr/boids/>`_ example that we have been loosely
following.  The starting point is a non-OOP version of the code that
implements the simulation.

The simulation takes a flock of virtual birds, and applies 3 rules:

    separation
        Try to avoid nearby boids

    alignment
        Try to move in the same direction as nearby boids

    cohesion
        Try to stay close to the center of the flock.

These rules are implemented by three functions with the same names.  In
addition, there is a function `do_one_step()` which takes arrays of positions
and velocities and computes the positions and velocities after one turn.  There
are additional parameters which can be passed to the simulation that control
the strength of each of the rules and the number of neighbors that are
used for each computation.

If you run this code in canopy, a matplotlib animation will be created for the
simulation and you can watch the flocking behavior live.  To run the
animation outside of Canopy from the command prompt, use::

    ipython --gui=qt4 boids.py

Question
--------

This code (as is often the case with scientific code) written in a
(fortunately, clean) "procedural" style of coding.  This is typical of code
which has been ported from languages like C, Matlab or Fortran, or which is
written by coders who have come from that background.  Procedural code is
fine, but you may notice some features of the code which could be made cleaner
by bundling up parameters into an object which holds all the state.

Re-write (or "refactor") this code into an object-oriented design.  This will
require you to:

    * create a class for the flock of boids (call it `Flock`).
    * this class should have attributes for the various parameters, like the
      position and velocity arrays, the weights, and even the private
      `kd_tree` which is used for computing neighbors.
    * it will need a constructor to initialize the state of the flock and the
      simulation parameters.
    * it should also have methods which correspond to the functions that exist.
      So there should be methods for each of the rules, as well as the
      `do_one_step` rule, and private methods for finding nearest neighbors
      and updating acceleration.
    * you might want to update the matplotlib animation at the end of the code 
      to work with the new class.

References
----------

Reynolds, C. W. (1987) Flocks, Herds, and Schools: A Distributed Behavioral
    Model, in Computer Graphics, 21(4) (SIGGRAPH '87 Conference Proceedings)
    pages 25-34.

"""


from numpy import array, newaxis, zeros, zeros_like
from numpy.linalg import norm
from numpy.random import uniform
from scipy.spatial import KDTree


def separation(kd_tree, positions, neighbor_count, eps=0.0):
    """ Avoid nearby boids, repulsion is inversely proportional to distance """
    distances, neighbors = nearest_neighbors(kd_tree, positions, neighbor_count, eps)
    distances = distances.clip(0.1)
    neighbor_positions = positions[neighbors]
    deltas = neighbor_positions - positions[:, newaxis, :]
    accel = (deltas/distances[:, :, newaxis]**2).sum(axis=1)
    return accel


def alignment(kd_tree, positions, velocities, neighbor_count, eps=0.0):
    """ Tend towards average heading of neighbors """
    distances, neighbors = nearest_neighbors(kd_tree, positions, neighbor_count, eps)
    avg_neighbor_velocities = velocities[neighbors].mean(axis=1)
    avg_delta = avg_neighbor_velocities - velocities
    return avg_delta


def cohesion(kd_tree, positions, neighbor_count, eps=0.0):
    """ Tend towards average position of neighbors """
    distances, neighbors = nearest_neighbors(kd_tree, positions, neighbor_count, eps)
    avg_neighbor_positions = positions[neighbors].mean(axis=1)
    avg_delta = avg_neighbor_positions - positions
    return avg_delta


def do_one_step(positions, velocities, forest_size=(150, 150), max_speed=5.0,
                separation_neighbor_count=10, separation_weight=1,
                alignment_neighbor_count=10, alignment_weight=0.02,
                cohesion_neighbor_count=51, cohesion_weight=0.02,
                eps=0.0):
    """ Perform one step of the simulation """
    # a KDTree allows us to find nearest neighbors more quickly
    kd_tree = KDTree(positions)

    # accumulate accelerations
    accel = zeros_like(velocities)
    accel += separation(kd_tree, positions, separation_neighbor_count, eps) * \
             separation_weight
    accel += alignment(kd_tree, positions, velocities, alignment_neighbor_count, eps) * \
             alignment_weight
    accel += cohesion(kd_tree, positions, cohesion_neighbor_count, eps) * \
             cohesion_weight

    # change velocity
    velocities += accel

    # clip velocity magnitude
    speeds = norm(velocities, axis=-1)
    too_fast = speeds >= max_speed
    velocities[too_fast] = velocities[too_fast]/speeds[too_fast, newaxis]*max_speed

    # change position
    positions += velocities

    # ensure boids stay within box (this wraps coordinates around)
    positions %= array(forest_size)


def nearest_neighbors(kd_tree, positions, count, eps=0.0):
    """ Utility function to find n nearest neighbors.

    This uses SciPy's KDTree object, which is documented here:
    http://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.KDTree.html

    """
    # If you don't know anything about the kd-tree data structure, that's fine
    # for the purposes of the exercise: just treat this as a black box which
    # finds the n nearest boids to an array of positions, and also computes
    # the distances to the boids from each point in the array.

    distances, neighbors = kd_tree.query(positions, count+1, eps)

    # first column is always the current boid, so ignore
    distances = distances[:, 1:]
    neighbors = neighbors[:, 1:]
    return distances, neighbors


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation

    # basic flock parameters
    forest_size = (150, 150)
    n_dim = len(forest_size)
    flock_size = 100

    # initial positions and velocities
    flock_positions = uniform(size=(flock_size, n_dim)) * array(forest_size)
    flock_velocities = zeros(shape=(flock_size, n_dim))

    # create a matplotlib animation of the flock
    fig = plt.figure()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                        xlim=(0, 150), ylim=(0,150))

    flock_plot, = ax.plot([], [], 'bo', ms=6)

    def init():
        flock_plot.set_data([], [])
        return flock_plot,

    def animate(i):
        global flock_plot, flock_positions, flock_velocities

        do_one_step(flock_positions, flock_velocities)
        flock_plot.set_data(flock_positions[:, 0], flock_positions[:, 1])
        return flock_plot,

    ani = animation.FuncAnimation(fig, animate, frames=100,
                                  interval=1, blit=True, init_func=init)
    plt.show()
