"""
Boids
=====

This exercise uses Flock classes from the super function exercise.

Question
--------

In the exercise for the super function you may have noticed that the
WallAvoidingFlock class is a subclass of the BoidFlock, but that the
wall-avoiding behavior is something that could potentially be used by any
subclass of the base Flock class.  In particular a flock which moves
randomly, but avoids walls would make sense.

Modify the classes in this exercise so that WallAvoidingFlock is a subclass
of Flock, and use multiple inheritance to create WallAvoidingRandomFlock and
WallAvoidingBoidFlock subclasses.

If you run this code in canopy, a matplotlib animation will be created for the
simulation and you can watch the flocking behavior live.  To run the
animation outside of Canopy from the command prompt, use::

    ipython --gui=qt4 boids_solution.py

Bonus
-----

The separation, alignment and cohesion behaviors are all independent of each
other.  Create SeparatingFlock, AligningFlock and CohesiveFlock subclasses,
and make the BoidsFlock class inherit from them.

References
----------

Reynolds, C. W. (1987) Flocks, Herds, and Schools: A Distributed Behavioral
    Model, in Computer Graphics, 21(4) (SIGGRAPH '87 Conference Proceedings)
    pages 25-34.

"""

from numpy import array, newaxis, zeros, zeros_like
from numpy.linalg import norm
from numpy.random import normal, uniform
from scipy.spatial import KDTree

class Flock(object):
    """ A base class for a similated flock of birds """

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = array(forest_size)
        self.n_dim = len(forest_size)

        self.positions = uniform(size=(self.size, self.n_dim))*self.forest_size
        self.velocities = zeros((size, self.n_dim))

    def accelerate(self):
        """ Accelerate the boids randomly """
        self.velocities += self._compute_acceleration()
        self._clip_velocity()

    def move(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self._clip_position()

    def do_one_step(self):
        """ Perform one step of the simulation """
        self.accelerate()
        self.move()

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = zeros(shape=(self.size, self.n_dim))
        return accel

    def _clip_velocity(self):
        pass

    def _clip_position(self):
        self.positions %= array(self.forest_size)


class RandomFlock(Flock):
    """A simulated flock of birds that moves randomly"""

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = normal(0, 1, (self.size, self.n_dim))
        return accel


class NeighborFlock(Flock):
    """A simulated flock of birds that keeps track of neighboring birds"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(NeighborFlock, self).__init__(size, forest_size)

        self.max_speed = 5.0
        self.eps = 0.0

    def do_one_step(self):
        """ Perform one step of the simulation """
        # a KDTree allows us to find nearest neighbors more quickly
        self._kd_tree = KDTree(self.positions)
        super(NeighborFlock, self).do_one_step()

    def _clip_velocity(self):
        """ Ensure no boid is going faster than the max speed """
        speeds = norm(self.velocities, axis=-1)
        too_fast = speeds >= self.max_speed
        self.velocities[too_fast] = (self.velocities[too_fast] /
            speeds[too_fast, newaxis]) * self.max_speed

    def _nearest_neighbors(self, count):
        """ Utility function to find n nearest neighbors.

        This uses SciPy's KDTree object, which is documented here:
        http://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.KDTree.html

        """
        # If you don't know anything about the kd-tree data structure, that's fine
        # for the purposes of the exercise: just treat this as a black box which
        # finds the n nearest boids to an array of positions, and also computes
        # the distances to the boids from each point in the array.

        distances, neighbors = self._kd_tree.query(self.positions, count+1,
                                                   self.eps)

        # first column is always the current boid, so ignore
        distances = distances[:, 1:]
        neighbors = neighbors[:, 1:]
        return distances, neighbors


class SeparatingFlock(NeighborFlock):
    """A flock where boids keep avoid their neighbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(SeparatingFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 10
        self.__weight = 1

    def separation(self):
        """Avoid nearby boids, repulsion is inversely proportional to distance"""
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        distances = distances.clip(0.1)
        neighbor_positions = self.positions[neighbors]
        deltas = neighbor_positions - self.positions[:, newaxis, :]
        accel = (deltas/distances[:, :, newaxis]**2).sum(axis=1)
        return accel

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(SeparatingFlock, self)._compute_acceleration()
        accel += self.separation() * self.__weight
        return accel


class AligningFlock(NeighborFlock):
    """A flock where boids move in the same direction as their neighbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(AligningFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 10
        self.__weight = 0.02

    def alignment(self):
        """ Tend towards average heading of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        avg_neighbor_velocities = self.velocities[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_velocities - self.velocities
        return avg_delta

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(AligningFlock, self)._compute_acceleration()
        accel += self.alignment() * self.__weight
        return accel


class CohesiveFlock(NeighborFlock):
    """A flock where boids move toward the centroid of their neigbors"""

    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        super(CohesiveFlock, self).__init__(size, forest_size)

        self.__neighbor_count = 51
        self.__weight = 0.02

    def cohesion(self):
        """ Tend towards average position of neighbors """
        distances, neighbors = self._nearest_neighbors(
            self.__neighbor_count)
        avg_neighbor_positions = self.positions[neighbors].mean(axis=1)
        avg_delta = avg_neighbor_positions - self.positions
        return avg_delta

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(CohesiveFlock, self)._compute_acceleration()
        accel += self.cohesion() * self.__weight
        return accel


class BoidFlock(SeparatingFlock, AligningFlock, CohesiveFlock):
    """ A simulated flock of birds that moves according to simple rules """
    pass


class WallAvoidingFlock(Flock):

    def wall_avoidance(self):
        """ If a wall is ahead, steer away from it """
        future_position = self.positions + self.velocities
        accel = zeros_like(self.velocities)
        for dimension in range(self.n_dim):
            # collision possible?
            collisions = ((future_position[..., dimension] < 0) | \
                          (future_position[..., dimension] >
                           self.forest_size[dimension]))
            # if so accelerate away from wall
            accel[collisions, dimension] = -self.velocities[collisions, dimension]
        return accel

    def _compute_acceleration(self):
        """ Compute the acceleration at a step """
        accel = super(WallAvoidingFlock, self)._compute_acceleration()
        accel += self.wall_avoidance()
        return accel

    def _clip_position(self):
        """ If beyond a wall, move back to wall location """
        for dimension in range(self.n_dim):
            collisions = self.positions[..., dimension] < 0
            self.positions[collisions, dimension] = 0
            collisions = self.positions[..., dimension] > self.forest_size[dimension]
            self.positions[collisions, dimension] = self.forest_size[dimension]


class WallAvoidingRandomFlock(WallAvoidingFlock, RandomFlock):
    pass


class WallAvoidingBoidFlock(WallAvoidingFlock, BoidFlock):
    pass


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation

    # create flocks
    flock_1 = WallAvoidingRandomFlock()
    flock_2 = WallAvoidingBoidFlock()

    # create a matplotlib animation of the flock
    fig = plt.figure()
    ax = fig.add_subplot(111, aspect='equal', autoscale_on=False,
                        xlim=(0, 150), ylim=(0,150))

    flock_1_plot, = ax.plot([], [], 'bo', ms=6)
    flock_2_plot, = ax.plot([], [], 'go', ms=6)

    def init():
        flock_1_plot.set_data([], [])
        flock_2_plot.set_data([], [])
        return flock_1_plot, flock_2_plot

    def animate(i):
        global flock_1_plot, flock_2_plot, flock_1, flock_2

        flock_1.do_one_step()
        flock_1_plot.set_data(flock_1.positions[:, 0], flock_1.positions[:, 1])
        flock_2.do_one_step()
        flock_2_plot.set_data(flock_2.positions[:, 0], flock_2.positions[:, 1])
        return flock_1_plot, flock_2_plot

    ani = animation.FuncAnimation(fig, animate, frames=100,
                                  interval=1, blit=True, init_func=init)
    plt.show()
