
# Flock Properties
# ================
# 
# In this example we will use what we learned in the lecture on properties to create some properties for the flock class.
# 

# Create properties that return the centroid of the flock (the average of the positions) and the average velocity.


from numpy import array, empty, zeros
from numpy.random import rand, normal
from matplotlib.pyplot import plot, subplot



class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)
    
    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    def __repr__(self):
        return "{0}(size={1}, forest_size={2})".format(
            self.__class__.__name__,
            repr(self.size),
            repr(self.forest_size),
        )

    def __str__(self):
        return "A flock of {0} boids".format(self.size)
    
    # your centroid property goes here
    
    
    # your average velocity goes here
    
    



from numpy import array
from numpy.random import rand, normal

class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)

    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    def __repr__(self):
        return "{0}(size={1}, forest_size={2})".format(
            self.__class__.__name__,
            repr(self.size),
            repr(self.forest_size),
        )

    def __str__(self):
        return "A flock of {0} boids".format(self.size)
    
    @property
    def centroid(self):
        return self.positions.mean(axis=0)
    
    @property
    def average_velocity(self):
        return self.velocity.mean(axis=0)
    


# Run the simulation for 500 steps and plot the centroid for each step as a 2D line plot.


flock = Flock()

# your solution goes here




flock = Flock()

centroids = empty((500, 2))
for i in range(500):
    flock.do_next_step()
    centroids[i] = flock.centroid

subplot(111, xlim=(0, 150), ylim=(0,150))
plot(centroids[:, 0], centroids[:, 1])
    


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
