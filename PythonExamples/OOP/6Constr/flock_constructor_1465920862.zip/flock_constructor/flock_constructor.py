
# Create a `Flock` class which has:
# 
# * a constructor which takes an argument for the number of "boids"
#   and the size of the forest that they live in, and
#   populates an array of position vectors (uniformly distributed around
#   the forest) and an array of velocity vectors (have these be zero,
#   initially).
# 
# * a method `accelerate_randomly()` that adds a random array to the
#   current velocity array.  Make these random vectors normally distributed
#   about 0 with standard deviation 1.
# 
# * a method `update_positions()` that adds the velocity array to the
#   position array.
# 
# * a method `do_next_step()` which calls `accelerate_randomly()` and then
#   calls `update_positions()`.


from numpy import array, zeros
from numpy.random import rand, normal
from matplotlib.pyplot import scatter



class Flock(object):
    """A simulated flock of birds"""
    
    # your "constructor" function goes here
    
    
    # your "accelerate_randomly" function goes here
    
    
    # your "update_positions" function goes here
    
    
    # your "do_next_step" function goes here
    
    


# Hint: The forest will have a width and height.  A quick way to generate uniform vectors in a region with a width and height looks like:
# 
#     rand(flock_size, 2)*array(forest_size)


# your code goes here


# Create an instance of your `Flock` class.  Plot the positions of the boids. Run it through 50 steps, and plot the positions again, in a different color. (If you are really enthusiastic, you could color the points by velocity).


# your code goes here


# Bonus
# -----
# 
# You probably have noticed that the boids have moved outside the bounds of the forest.  Modify the `update_positions()` function so that the boids always stay within the rectangle $[0, width] \times [0, height]$.
# 
# You could do this by using the modulo operator `%` on each dimension (which will cause the boids to "wrap around") or with some more work, you could make them "bounce" off the sides of the forest.


# your code goes here


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
