
# Create a `Flock` class which has:
# 
# * a constructor which takes an argument for the number of "boids"
#   and the size of the forest that they live in, and
#   populates an array of position vectors (uniformly distributed around
#   the forest) and an array of velocity vectors (have these be zero,
#   initially).
# 
# * a method `accelerate_randomly()` that adds a random array to the
#   current velocity array.  Make these random vectors normally distributed
#   about 0 with standard deviation 1.
# 
# * a method `update_positions()` that adds the velocity array to the
#   position array.
# 
# * a method `do_next_step()` which calls `accelerate_randomly()` and then
#   calls `update_positions()`.


from numpy import array, zeros
from numpy.random import rand, normal
from matplotlib.pyplot import scatter



class Flock(object):
    """A simulated flock of birds"""
    
    # your "constructor" function goes here
    
    
    # your "accelerate_randomly" function goes here
    
    
    # your "update_positions" function goes here
    
    
    # your "do_next_step" function goes here
    
    


# Hint: The forest will have a width and height.  A quick way to generate uniform vectors in a region with a width and height looks like:
# 
#     rand(flock_size, 2)*array(forest_size)


class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
    
    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()


# Create an instance of your `Flock` class.  Plot the positions of the boids. Run it through 50 steps, and plot the positions again, in a different color. (If you are really enthusiastic, you could color the points by velocity).


flock = Flock()

scatter(flock.positions[:, 0], flock.positions[:, 1])

for i in range(50):
    flock.do_next_step()

scatter(flock.positions[:, 0], flock.positions[:, 1], color='red')


# Bonus
# -----
# 
# You probably have noticed that the boids have moved outside the bounds of the forest.  Modify the `update_positions()` function so that the boids always stay within the rectangle $[0, width] \times [0, height]$.
# 
# You could do this by using the modulo operator `%` on each dimension (which will cause the boids to "wrap around") or with some more work, you could make them "bounce" off the sides of the forest.


class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        # simple "wrap-around"
        self.positions %= array(self.forest_size)
        
        # bounce (not quite a complete solution for very fast boids)
        #off_left = self.positions[:, 0] < 0
        #while off_left.
        #self.positions[off_left, 0] = -self.positions[off_left, 0]
        #self.velocities[off_left, 0] = -self.velocities[off_left, 0]
        #
        #off_right = self.positions[:, 0] > self.forest_size[0]
        #self.positions[off_right, 0] = self.forest_size[0]-self.positions[off_right, 0]
        #self.velocities[off_right, 0] = -self.velocities[off_right, 0]
        # 
        #off_bottom = self.positions[:, 1] < 0
        #self.positions[off_bottom, 1] = -self.positions[off_bottom, 1]
        #self.velocities[off_bottom, 1] = -self.velocities[off_bottom, 1]
        #
        #off_top = self.positions[:, 1] > self.forest_size[1]
        #self.positions[off_top, 1] = self.forest_size[1]-self.positions[off_top, 1]
        #self.velocities[off_top, 1] = -self.velocities[off_top, 1]
        
    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
