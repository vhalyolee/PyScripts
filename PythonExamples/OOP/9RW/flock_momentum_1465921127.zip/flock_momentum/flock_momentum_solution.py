
# Add a momentum property to the Flock class.  The returned value should be the product of the masses and the velocities.  When the momentum array is set, it should divide the input array by the masses and set the velocity to the resulting values.


from numpy import array, newaxis, zeros
from numpy.random import rand, normal, lognormal



class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
        self.masses = lognormal(1, 0.5, size)
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)

    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    def __repr__(self):
        return "{0}(size={1}, forest_size={2})".format(
            self.__class__.__name__,
            repr(self.size),
            repr(self.forest_size),
        )

    def __str__(self):
        return "A flock of {0} boids".format(self.size)
    
    @property
    def centroid(self):
        return self.positions.mean(axis=0)
    
    @property
    def average_velocity(self):
        return self.velocity.mean(axis=0)
    
    # your solution goes here
    



from numpy import array, newaxis
from numpy.random import rand, normal


class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
        self.masses = lognormal(1, 0.5, size)
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)

    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    def __repr__(self):
        return "{0}(size={1}, forest_size={2})".format(
            self.__class__.__name__,
            repr(self.size),
            repr(self.forest_size),
        )

    def __str__(self):
        return "A flock of {0} boids".format(self.size)
    
    @property
    def centroid(self):
        return self.positions.mean(axis=0)
    
    @property
    def average_velocity(self):
        return self.velocity.mean(axis=0)
    
    @property
    def momentum(self):
        # Use NumPy's newaxis to view self.masses in the right shape.
        # See lectures "Indexing with newaxis" and "Array broadcasting"
        # in the NumPy course for more information.
        return self.masses[:, newaxis] * self.velocities

    @momentum.setter
    def momentum(self, value):
        self.velocities = value / self.masses[:, newaxis]
        
    



from numpy import ones_like

# check that the code works
flock = Flock()
flock.do_next_step()

# test that the getter works, by printing the first
print flock.momentum[0]

# test that the setter works
flock.momentum = ones_like(flock.momentum)
print flock.velocities[0]


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
