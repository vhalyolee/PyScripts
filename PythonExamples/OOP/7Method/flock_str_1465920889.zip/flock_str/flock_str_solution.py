
# Write a `__repr__` method for the `Flock` class that displays the paramters to the "constructor" correctly.
# 
# Write a `__str__` method for the `Flock` class that gives you a description like `"A flock of 100 boids."`


from numpy import array, zeros
from numpy.random import rand, normal



class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)
    
    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    # your __repr__ method goes here


    # your __str__ method goes here
    



from numpy import array
from numpy.random import rand, normal

class Flock(object):
    """A simulated flock of birds"""
    
    def __init__(self, size=100, forest_size=(150, 150)):
        """ Initialize the flock """
        self.size = size
        self.forest_size = forest_size
        self.positions = rand(size, 2)*array(forest_size)
        self.velocities = zeros((size, 2))
    
    def accelerate_randomly(self):
        """ Accelerate the boids randomly """
        self.velocities += normal(0, 1, (self.size, 2))
    
    def update_positions(self):
        """ Update the positions of the boids """
        self.positions += self.velocities
        self.positions %= array(self.forest_size)
    
    def do_next_step(self):
        """ Perform one step of the simulation """
        self.accelerate_randomly()
        self.update_positions()
    
    def __repr__(self):
        return "{0}(size={1}, forest_size={2})".format(
            self.__class__.__name__,
            repr(self.size),
            repr(self.forest_size),
        )

    def __str__(self):
        return "A flock of {0} boids".format(self.size)



flock = Flock()
flock



print flock


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
