import numpy as np
from scipy.ndimage.measurements import label


class Forest(object):
    """Forest can grow trees which eventually die."""
    def __init__(self, size=(150, 150), p_sapling=0.0025):
        self.size = size
        self.trees = np.zeros(self.size, dtype=bool)
        self.p_sapling = p_sapling

    def __repr__(self):
        my_repr = "{}(size={})".format(self.__class__.__name__, self.size)
        return my_repr

    def __str__(self):
        return self.__class__.__name__

    @property
    def losses(self):
        "generic property describing losses in the forest."
        return np.zeros(self.size)

    @property
    def num_cells(self):
        """Number of cells available for growing trees."""
        # assuming 2D forest
        return self.size[0] * self.size[1]

    @property
    def tree_fraction(self):
        num_trees = self.trees.sum()
        return float(num_trees) / self.num_cells

    def _rand_bool(self, p):
        return np.random.uniform(size=self.size) < p

    def grow_trees(self):
        growth_sites = self._rand_bool(self.p_sapling)
        self.trees[growth_sites] = True

    def advance_one_step(self):
        self.grow_trees()


class BurnableForest(Forest):
    """BurnableForest supports fires
    """
    def __init__(self, p_lightning=5.0e-6, **kwargs):
        self.p_lightning = p_lightning
        super(BurnableForest, self).__init__(**kwargs)
        self.fires = np.zeros(self.size, dtype=bool)

    @property
    def losses(self):
        return self.fires

    @property
    def fire_fraction(self):
        num_fires = self.fires.sum()
        return float(num_fires) / self.num_cells

    def advance_one_step(self):
        super(BurnableForest, self).advance_one_step()
        self.start_fires()
        self.burn_trees()

    def start_fires(self):
        lightning_strikes = self._rand_bool(self.p_lightning) & self.trees
        self.fires[lightning_strikes] = True

    def burn_trees(self):
        pass


class SlowBurnForest(BurnableForest):
    def burn_trees(self):
        working_size = (self.size[0] + 2, self.size[1] + 2)
        fires = np.zeros(working_size, dtype=bool)
        fires[1:-1, 1:-1] = self.fires
        north = fires[:-2, 1:-1]
        south = fires[2:, 1:-1]
        east = fires[1:-1, :-2]
        west = fires[1:-1, 2:]
        new_fires = (north | south | east | west) & self.trees
        self.trees[self.fires] = False
        self.fires = new_fires


class InstantBurnForest(BurnableForest):
    def burn_trees(self):
        # treat self.fires as lightning strikes
        strikes = self.fires
        groves, num_groves = label(self.trees)
        fires = set(groves[strikes])
        self.fires.fill(False)
        for fire in fires:
            self.fires[groves == fire] = True
        self.trees[self.fires] = False
        self.fires.fill(False)
