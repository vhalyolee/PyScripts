"""Create a MoldProneForest, inheriting from Forest and implementing its
interface so that instances of MoldProneForest and InstantBurningForest can
be compared in a simulation.

The behavior of the mold is to land with probability p_mold.  If the density
of trees is greater than the critical_density, where the critical_density is
defined as the number of trees next to (north, south, east, west) a given
tree, that tree dies.  A sample implementation is given in the starter code.
Feel free to modify it!

To match the Forest interface, you will need to modify __init__, losses(), and
advance_one step().
"""
import numpy as np

from forest import Forest, InstantBurnForest, SlowBurnForest


class MoldProneForest(Forest):
    """Tree-killing mold can grow in tree groves of a certain size.

    Parameters
    ==========

        p_mold: float
            probability of mold spores landing in any cell in a given day

        critical_density: int
            critical density at which mold spores will grow and cause a tree to
            die.  Expressed as the number of trees in the four neighboring
            cells (north, south, east, west).

        other parameters inherited from Forest: size, p_sapling

    Properties
    ==========

        losses: array
            For the mold-prone forest this would be the locations of tree deaths
            from mold

        mold_fraction: float
            Fraction of the forest with mold growth in a time step.

        other properties inherited from Forest: num_cells, tree_fraction

    Methods
    =======

        advance_one_step()

        other methods inherited from Forest: advance_one_step(), grow_trees()

    """
    def __init__(self, p_mold=3.0e-3, critical_density=3, *args, **kwargs):
        super(MoldProneForest, self).__init__(*args, **kwargs)
        self.p_mold = p_mold
        self.critical_density = critical_density
        self.mold = np.zeros(self.trees.shape, dtype=bool)

    @property
    def losses(self):
        "Return the locations of tree deaths from mold in the current step."
        return self.mold

    @property
    def mold_fraction(self):
        "Return the fraction of trees infected with mold in the current step."
        return self.mold.sum() / float(self.num_cells)

    def advance_one_step(self):
        "Advance one step in the life of a mold-prone forest"
        self.grow_trees()
        self._grow_mold_and_kill_trees()

    def _grow_mold_and_kill_trees(self):
        """Sample implementation of mold growth in a forest.

        Feel free to replace with your own implementation."""
        # Make a working area that's bigger than the forest by two elements in
        # each direction.  This lets us calculate the density of trees at the
        # edge by including elements off the edge of the forest.

        # First calculate the required size
        working_size = (self.size[0] + 2, self.size[1] + 2)

        # Now make an array of the larger size and set the values in the center
        # equal to the values of the forest.  tmp_trees looks like the forest
        # array but with a ring of zeros around the edge
        tmp_trees = np.zeros(working_size, dtype=np.int8)
        tmp_trees[1:-1, 1:-1] = self.trees

        # Use NumPy slicing to count the trees nouth, south, east, and west of
        # each tree.  See the lecture on Numpy slicing and the exercise on
        # image filtering for more detail on this efficient and high speed
        # trick.
        north = tmp_trees[:-2, 1:-1]
        south = tmp_trees[2:, 1:-1]
        east = tmp_trees[1:-1, :-2]
        west = tmp_trees[1:-1, 2:]
        density = north + south + east + west
        # Now we have density, make a mask of mold-prone locations
        mold_prone_trees = density >= self.critical_density

        # Grow mold in the mold-prone locations
        self.mold = self._rand_bool(self.p_mold) & mold_prone_trees
        # Kill the trees where the mold grew
        self.trees[self.mold] = False


if __name__ == "__main__":
    import matplotlib.pyplot as plt

    moldy_forest = MoldProneForest()
    inst_burn_forest = InstantBurnForest()
    slow_burn_forest = SlowBurnForest()
    forests = [moldy_forest, inst_burn_forest, slow_burn_forest]
    tree_history = []
    for i in xrange(2500):
        for forest in forests:
            forest.advance_one_step()
        tree_history.append([f.tree_fraction for f in forests])
    plt.plot(tree_history)
    plt.legend(forests)
    plt.show()
