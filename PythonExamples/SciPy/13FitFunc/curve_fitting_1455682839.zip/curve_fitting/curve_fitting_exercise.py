
# Curve Fitting
# =============
# 
# SciPy provides many methods to fit curves to your data points. The fitted curves can be a much cleaner way to represent your data.
# 
# Question 1
# ----------
# Plot the following noisy, sinusoidal data produced for you with a randomized generator.


def noisy_data(x):
    phase = pi / 4
    frequency = 0.85
    noise = norm.rvs(size=x.shape) * 0.5
    return np.sin(x * frequency + phase) + noise

x = np.linspace(-pi, pi, 100)
y = noisy_data(x)



# your code goes here


# Question 2
# ----------
# 
# Take a look at your data. Could you use a polynomial to fit the data? What order polynomial is appropriate?
# Plot your fit against the original data.
# How good is the fit? Can you make the fit better by increasing the polynomial order?

# Hint: `1 - R ** 2` can be calculated by dividing the sum of the squared model error by the overall variation.


from numpy import polyfit, poly1d



# your code goes here


# Question 3
# ----------
# 
# You find out that your data has the form `y=sin(ωx+ϕ)`. Set up a function to fit the data to this form.


# your code goes here


# Question 4
# ----------
# 
# Use `curve_fit()` to find the best fit for the frequency and phase shift parameters in the data.


from scipy.optimize import curve_fit



# your code goes here


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
