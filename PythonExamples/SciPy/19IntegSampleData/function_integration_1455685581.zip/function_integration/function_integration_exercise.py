
# Function integration
# ====================
# 
# This is an exercise to try out the numerical integration routines in SciPy, which we can compare to some analytic results, to see how well the numerical integration performs.

# Question 1
# ----------
# 
# Use `scipy.integrate.quad` to integrate sin from 0 to $\dfrac{\pi}{2}$ and print out the result.

# Hint: Look at the docstring for quad with
# `>>> quad?`


from numpy import pi, sin
from scipy.integrate import quad



# your code goes here


# Question 2
# ----------
# 
# Integrate sin from 0 to x where x is a range of values from 0 to $2\pi$. Compare this to the exact solution, -cos(x) + cos(0), on a plot. Also plot the error between the two.

# Hint: Use `vectorize` so that `integrate.quad` works with arrays as inputs and produces arrays as outputs.


from numpy import linspace, vectorize, cos
from matplotlib.pyplot import plot, legend, show, subplot, xlabel, ylabel, title

x = linspace(0, 2*pi, 101)



# your code goes here


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
