
# Name String
# ===========
# 
# We would like to create a custom welcome message for a future application  that greats the user using his/her name. 
# 
# Question 1
# ----------
# Create a string with your first name  and assign it to a variable 'fst_name'.


# your code goes here


# Question 2
# ----------
# Create another one with your last name and assign it to a variable  'last_name'. 


# your code goes here


# Question 3
# ----------
# Print a third string made of the concatenation of "Hello ", and the two  variables above.


# your code goes here


# Question 4
# ----------
# Now print a string full of the character "=" to underline the previous output. For example, if your name is Eric Jones, your welcome message is 
# 
#     
#     Hello Eric Jones 
# 
# so you should then print 16 occurences of "=". 
# 
# Note: Your code should work with any name (in other words, you can't assume that you can count the length of the name).

# Hint: The number of characters needed is the length of "Hello ", the length of the first name, the length of the last name, plus 1 more for the space in between.


# your code goes here


# Copyright 2008-2016, Enthought, Inc.  
# Use only permitted under license.  Copying, sharing, redistributing or other unauthorized use strictly prohibited.  
# http://www.enthought.com
