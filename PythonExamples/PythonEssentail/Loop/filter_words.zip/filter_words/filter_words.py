"""
Filter Words
------------

We provide you with the following beginning of a famous children song.
Print out only words that start with "o", ignoring case:

    lyrics = '''My Bonnie lies over the ocean.
                My Bonnie lies over the sea.
                My Bonnie lies over the ocean.
                Oh bring back my Bonnie to me.
                '''

Bonus:
Print out words only once.
"""

lyrics = '''My Bonnie lies over the ocean.
            My Bonnie lies over the sea.
            My Bonnie lies over the ocean.
            Oh bring back my Bonnie to me.
         '''
